const _0x1cc3 = [
  "🏆Người\x20dùng\x20<b>",
  "849732OKdkLS",
  "address_USDT",
  "default",
  "query",
  "ABI_USDT_MAINNET",
  "</b>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-\x20Vui\x20lòng\x20nạp\x20thêm\x20vào\x20ví\x20ADMIN:\x20💸<b>",
  "toHex",
  "replace",
  "554781iiTFUK",
  "eth",
  "https://rinkeby.infura.io/v3/",
  "\x20BNB\x20cho\x20USER",
  "\x20USDT\x20cho\x20Ví\x20ADMIN:\x20",
  "mainnet",
  "Contract",
  "mess",
  "\x20USDT\x20vào\x20Ví!",
  "\x0atxHash:\x20",
  "call",
  "4eoNpET",
  "0x0",
  "CONTRACT_USDT_TEST",
  "utils",
  "result",
  "https://data-seed-prebsc-1-s1.binance.org:8545",
  "hex",
  "479622DkxckD",
  "getTransactionCount",
  "Nạp\x20tiền\x20(Nội\x20bộ)",
  "serialize",
  "toString",
  "1AXfSVd",
  "ADDRESS_ETH_USDT",
  "toWei",
  "CONTRACT_USDT_MAIN",
  "../config",
  "init",
  "1TrYOeA",
  "stringify",
  "email",
  "Bạn\x20đã\x20nạp\x20$",
  "ether",
  "710259nvrnfB",
  "bep20",
  "205682ccZPhq",
  "bnb",
  "UPDATE\x20users\x20SET\x20money_usdt\x20=\x20money_usdt\x20+\x20?\x20where\x20nick_name\x20=\x20?",
  "estimateGas",
  "privateKey_USDT",
  "ABI_USDT_TESTNNET",
  "catch",
  "exports",
  "send",
  "</b>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20🏋️Số\x20dư\x20ví\x20ADMIN\x20hiện\x20tại\x20BNB:\x20<b>",
  "sign",
  "Transaction",
  "43356nXnwJv",
  "sendMessNap",
  "\x20vừa\x20chuyển\x20\x0a📌\x200.0021\x20BSC\x20cho\x20Ví\x20người\x20dùng:\x20",
  "../helpers",
  "../database",
  "</b>\x20BNB\x20phí\x20để\x20chuyển\x20",
  "\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20txHash:\x20",
  "methods",
  "ACXPSZEP9QKN5QU2NYDGTP72CRT86MMVAT",
  "then",
  "sendSignedTransaction",
  "</b>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20🏘Địa\x20chỉ\x20User:\x20",
  "PATH_SYS_CONFIG",
  "HttpProvider",
  "format",
  "\x20vừa\x20chuyển\x20\x0a📌💲\x20",
  "IS_TEST_SMART_CHAIN",
  "providers",
  "fromWei",
  "success",
  "status",
  "getConfig",
  "petersburg",
  "SELECT\x20nick_name,\x20address_USDT,\x20privateKey_USDT\x20FROM\x20users\x20WHERE\x20email\x20=\x20?",
  "ethereumjs-tx",
  "gwei",
  "360455vwEVjR",
  "</b>\x0a🏘Địa\x20chỉ:\x20",
  "NumberFormat",
  ".\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20🏋️Vừa\x20nạp\x20USDT:\x20<b>",
  "🏆🏘Địa\x20chỉ\x20ADMIN:\x20",
  "PRIVATE_KEY_ETH_TRANSACTION",
  "projectId",
  "rinkeby",
  "etherscan-api",
  "forCustomChain",
  "https://mainnet.infura.io/v3/",
  "ethereumjs-common",
  "0.0021",
  "testnet",
  "account",
  "nick_name",
  "https://bsc-dataseed1.binance.org",
  "bscscan-api",
  "encodeABI",
  "from",
  "INSERT\x20INTO\x20trade_history\x20(from_u,\x20to_u,\x20type_key,\x20type,\x20network,\x20currency,\x20amount,\x20real_amount,\x20pay_fee,\x20note,\x20status,\x20created_at)\x0a\x20\x20\x20\x20\x20\x20\x20\x20values(?,?,?,?,?,?,?,?,?,?,?,now())",
  "balance",
];
const _0x4662 = function (_0x4664ad, _0x559901) {
  _0x4664ad = _0x4664ad - 0x113;
  let _0x1cc357 = _0x1cc3[_0x4664ad];
  return _0x1cc357;
};
const _0x355c26 = _0x4662;
(function (_0x1a5f5b, _0x694ab0) {
  const _0x38e771 = _0x4662;
  while (!![]) {
    try {
      const _0x5df80e =
        parseInt(_0x38e771(0x141)) +
        parseInt(_0x38e771(0x12f)) * parseInt(_0x38e771(0x146)) +
        parseInt(_0x38e771(0x179)) * -parseInt(_0x38e771(0x14c)) +
        parseInt(_0x38e771(0x15f)) * -parseInt(_0x38e771(0x13a)) +
        parseInt(_0x38e771(0x127)) +
        -parseInt(_0x38e771(0x153)) +
        -parseInt(_0x38e771(0x151));
      if (_0x5df80e === _0x694ab0) break;
      else _0x1a5f5b["push"](_0x1a5f5b["shift"]());
    } catch (_0x5a8545) {
      _0x1a5f5b["push"](_0x1a5f5b["shift"]());
    }
  }
})(_0x1cc3, 0x6a08b);
const Web3 = require("web3"),
  Tx = require(_0x355c26(0x177))[_0x355c26(0x15e)],
  common = require(_0x355c26(0x11b)),
  db = require(_0x355c26(0x163)),
  Tele = require("../auth/telegram_notify"),
  config = require(_0x355c26(0x14a)),
  Helper = require(_0x355c26(0x162)),
  fileSys = config[_0x355c26(0x16b)];
var redataSys = Helper[_0x355c26(0x174)](fileSys),
  TOKEN_KEY_Ether = "X6P7HHXBKYX2G6DPY5BTKKIIMUU67F1JKV",
  TOKEN_KEY_Bsc = _0x355c26(0x167),
  apiEther = null,
  apiBsc = null,
  web3 = null,
  web3Bsc = null,
  LIST_USER_ONLINE = null,
  ContractAddress = null,
  USDTJSON = null,
  USDT_BSC = null;
function setConnectSmartChain(_0x4731d0) {
  const _0x43e8d0 = _0x355c26;
  !_0x4731d0
    ? ((USDTJSON = Helper["getConfig"](config[_0x43e8d0(0x12b)])),
      (ContractAddress = redataSys[_0x43e8d0(0x149)]),
      (apiEther = require(_0x43e8d0(0x118))[_0x43e8d0(0x14b)](
        TOKEN_KEY_Ether,
        _0x43e8d0(0x134),
      )),
      (web3 = new Web3(
        new Web3[_0x43e8d0(0x170)][_0x43e8d0(0x16c)](
          _0x43e8d0(0x11a) + redataSys["projectId"],
        ),
      )),
      (apiBsc = require(_0x43e8d0(0x121))[_0x43e8d0(0x14b)](
        TOKEN_KEY_Bsc,
        _0x43e8d0(0x134),
      )),
      (web3Bsc = new Web3(
        new Web3["providers"][_0x43e8d0(0x16c)](_0x43e8d0(0x120)),
      )),
      (USDT_BSC = new web3Bsc[_0x43e8d0(0x130)][_0x43e8d0(0x135)](
        USDTJSON,
        ContractAddress,
      )))
    : ((USDTJSON = Helper[_0x43e8d0(0x174)](config[_0x43e8d0(0x158)])),
      (ContractAddress = redataSys[_0x43e8d0(0x13c)]),
      (apiEther = require(_0x43e8d0(0x118))[_0x43e8d0(0x14b)](
        TOKEN_KEY_Ether,
        _0x43e8d0(0x117),
      )),
      (web3 = new Web3(
        new Web3[_0x43e8d0(0x170)]["HttpProvider"](
          _0x43e8d0(0x131) + redataSys[_0x43e8d0(0x116)],
        ),
      )),
      (apiBsc = require(_0x43e8d0(0x121))[_0x43e8d0(0x14b)](
        TOKEN_KEY_Bsc,
        _0x43e8d0(0x11d),
      )),
      (web3Bsc = new Web3(
        new Web3["providers"][_0x43e8d0(0x16c)](_0x43e8d0(0x13f)),
      )),
      (USDT_BSC = new web3Bsc[_0x43e8d0(0x130)]["Contract"](
        USDTJSON,
        ContractAddress,
      )));
}
setConnectSmartChain(redataSys[_0x355c26(0x16f)]),
  setInterval(() => {
    const _0x5f90e0 = _0x355c26;
    (redataSys = Helper[_0x5f90e0(0x174)](fileSys)),
      setConnectSmartChain(redataSys["IS_TEST_SMART_CHAIN"]);
  }, 0xea60);
function formatPrice(_0x5eb8cb, _0x48c827) {
  const _0xc1569 = _0x355c26;
  var _0xf57b20 = new Intl[_0xc1569(0x17b)]("en-US", {
    minimumFractionDigits: _0x48c827,
  });
  return _0xf57b20[_0xc1569(0x16d)](_0x5eb8cb);
}
async function SEND_BNB_TO_WALLET_USER(
  _0x1f8854,
  _0x54db7c,
  _0x54e9ef,
  _0x338b3b,
) {
  const _0x5bbefc = _0x355c26;
  let _0x59858b = redataSys["ADDRESS_ETH_TRANSACTION"],
    _0x44fdd3 = await apiBsc[_0x5bbefc(0x11e)]["balance"](_0x59858b);
  if (_0x44fdd3[_0x5bbefc(0x173)] == 0x1) {
    let _0x4ea859 = _0x44fdd3[_0x5bbefc(0x13e)],
      _0x2104f1 = Number(_0x4ea859),
      _0x56b7db = _0x1f8854,
      _0x445f2c = 0xa,
      _0x190ab3 = 0x5208,
      _0xd636fd = web3Bsc[_0x5bbefc(0x13d)][_0x5bbefc(0x148)](
        (_0x190ab3 * _0x445f2c)["toString"](),
        _0x5bbefc(0x178),
      ),
      _0x29be08 = _0x1f8854 + Number(_0xd636fd);
    if (_0x2104f1 >= _0x29be08)
      try {
        const _0x140931 = _0x56b7db;
        let _0x159aa0 = _0x338b3b,
          _0x324044 = Buffer[_0x5bbefc(0x123)](
            redataSys[_0x5bbefc(0x115)]["replace"]("0x", ""),
            _0x5bbefc(0x140),
          );
        web3Bsc[_0x5bbefc(0x130)][_0x5bbefc(0x142)](
          _0x59858b,
          (_0x43e8a5, _0x577915) => {
            const _0x116378 = _0x5bbefc,
              _0x39680e = {
                nonce: web3Bsc[_0x116378(0x13d)][_0x116378(0x12d)](_0x577915),
                from: _0x59858b,
                to: _0x159aa0,
                value: web3Bsc[_0x116378(0x13d)][_0x116378(0x12d)](_0x140931),
                gasLimit: web3Bsc[_0x116378(0x13d)]["toHex"](_0x190ab3),
                gasPrice: web3Bsc[_0x116378(0x13d)]["toHex"](
                  web3Bsc[_0x116378(0x13d)][_0x116378(0x148)](
                    _0x445f2c[_0x116378(0x145)](),
                    _0x116378(0x178),
                  ),
                ),
              };
            let _0x160961 = redataSys[_0x116378(0x16f)] ? 0x61 : 0x38;
            const _0x4f4141 = common[_0x116378(0x129)][_0x116378(0x119)](
                "mainnet",
                { name: "bnb", networkId: _0x160961, chainId: _0x160961 },
                "petersburg",
              ),
              _0x9626c1 = new Tx(_0x39680e, { common: _0x4f4141 });
            _0x9626c1[_0x116378(0x15d)](_0x324044);
            const _0x2d7705 = _0x9626c1[_0x116378(0x144)](),
              _0x141f86 = "0x" + _0x2d7705["toString"](_0x116378(0x140));
            web3Bsc["eth"][_0x116378(0x169)](
              _0x141f86,
              (_0x40f577, _0x38ddfd) => {
                const _0x24ae12 = _0x116378;
                void 0x0 !== _0x38ddfd &&
                  Tele[_0x24ae12(0x160)](
                    _0x24ae12(0x114) +
                      _0x59858b +
                      _0x24ae12(0x161) +
                      _0x159aa0 +
                      _0x24ae12(0x138) +
                      _0x38ddfd,
                  );
              },
            );
          },
        );
      } catch (_0x54e98d) {}
    else {
      let _0x22f639 = _0x29be08 - _0x2104f1;
      Tele["sendMessNap"](
        _0x5bbefc(0x126) +
          _0x54e9ef +
          _0x5bbefc(0x16a) +
          _0x338b3b +
          _0x5bbefc(0x113) +
          web3Bsc[_0x5bbefc(0x13d)][_0x5bbefc(0x171)](
            _0x54db7c[_0x5bbefc(0x145)](),
            _0x5bbefc(0x150),
          ) +
          _0x5bbefc(0x15c) +
          web3Bsc[_0x5bbefc(0x13d)][_0x5bbefc(0x171)](
            _0x2104f1["toString"](),
            "ether",
          ) +
          _0x5bbefc(0x12c) +
          web3Bsc[_0x5bbefc(0x13d)][_0x5bbefc(0x171)](
            _0x22f639[_0x5bbefc(0x145)](),
            _0x5bbefc(0x150),
          ) +
          _0x5bbefc(0x164) +
          web3Bsc["utils"]["fromWei"](_0x1f8854[_0x5bbefc(0x145)](), "ether") +
          _0x5bbefc(0x132),
      );
    }
  }
}
async function SCAN_BEP20_LOADING(_0x352249, _0x25b647) {
  const _0x5949c4 = _0x355c26;
  if (void 0x0 !== _0x352249["address_USDT"]) {
    let _0x2fa596 = await USDT_BSC["methods"]
      ["balanceOf"](_0x352249["address_USDT"])
      [_0x5949c4(0x139)]();
    if (_0x2fa596 > 0x0) {
      let _0x487fb3 = await apiBsc["account"][_0x5949c4(0x125)](
        _0x352249[_0x5949c4(0x128)],
      );
      try {
        if (_0x487fb3[_0x5949c4(0x173)] == 0x1) {
          let _0x35a70d = Number(
              web3Bsc[_0x5949c4(0x13d)][_0x5949c4(0x148)](
                _0x5949c4(0x11c),
                _0x5949c4(0x150),
              ),
            ),
            _0x2497ea = _0x487fb3[_0x5949c4(0x13e)],
            _0x276024 = Number(_0x2497ea);
          if (_0x276024 >= _0x35a70d) {
            let _0x38582e =
                web3Bsc[_0x5949c4(0x13d)][_0x5949c4(0x12d)](_0x2fa596),
              _0x153e1d = 0xa,
              _0x1d5fb2 = 0x33450,
              _0x3feda4 = web3Bsc[_0x5949c4(0x13d)]["toWei"](
                _0x153e1d[_0x5949c4(0x145)](),
                _0x5949c4(0x178),
              ),
              _0x38240c = redataSys[_0x5949c4(0x147)],
              _0x52ddee = Buffer[_0x5949c4(0x123)](
                _0x352249[_0x5949c4(0x157)][_0x5949c4(0x12e)]("0x", ""),
                _0x5949c4(0x140),
              );
            web3Bsc[_0x5949c4(0x130)]
              ["getTransactionCount"](_0x352249[_0x5949c4(0x128)])
              [_0x5949c4(0x168)]((_0x26cd53) => {
                const _0x46e7b5 = _0x5949c4;
                let _0x56353a = {
                    from: _0x352249[_0x46e7b5(0x128)],
                    gasPrice: web3Bsc["utils"][_0x46e7b5(0x12d)](_0x3feda4),
                    gasLimit: web3Bsc[_0x46e7b5(0x13d)]["toHex"](_0x1d5fb2),
                    to: ContractAddress,
                    value: _0x46e7b5(0x13b),
                    data: USDT_BSC[_0x46e7b5(0x166)]
                      ["transfer"](_0x38240c, _0x38582e)
                      [_0x46e7b5(0x122)](),
                    nonce: web3Bsc[_0x46e7b5(0x13d)]["toHex"](_0x26cd53),
                  },
                  _0x2ad05f = redataSys[_0x46e7b5(0x16f)] ? 0x61 : 0x38;
                const _0x578021 = common[_0x46e7b5(0x129)][_0x46e7b5(0x119)](
                    "mainnet",
                    {
                      name: _0x46e7b5(0x154),
                      networkId: _0x2ad05f,
                      chainId: _0x2ad05f,
                    },
                    _0x46e7b5(0x175),
                  ),
                  _0x506409 = new Tx(_0x56353a, { common: _0x578021 });
                _0x506409[_0x46e7b5(0x15d)](_0x52ddee);
                const _0x38ca57 = _0x506409[_0x46e7b5(0x144)](),
                  _0x330b17 = "0x" + _0x38ca57[_0x46e7b5(0x145)]("hex");
                web3Bsc[_0x46e7b5(0x130)][_0x46e7b5(0x169)](
                  _0x330b17,
                  (_0x178e03, _0x4313a3) => {
                    const _0x3a2d5f = _0x46e7b5;
                    if (_0x178e03) return;
                    void 0x0 !== _0x4313a3 &&
                      web3Bsc[_0x3a2d5f(0x130)]
                        [_0x3a2d5f(0x156)](_0x56353a)
                        [_0x3a2d5f(0x168)]((_0x2f965e) => {
                          const _0x342ff1 = _0x3a2d5f;
                          let _0x144c65 =
                              _0x2f965e *
                              web3Bsc[_0x342ff1(0x13d)][_0x342ff1(0x171)](
                                _0x153e1d["toString"](),
                                _0x342ff1(0x178),
                              ),
                            _0x3a4f1c = web3Bsc[_0x342ff1(0x13d)][
                              _0x342ff1(0x171)
                            ](_0x2fa596[_0x342ff1(0x145)](), _0x342ff1(0x150));
                          addMoneyToUser(
                            _0x3a4f1c,
                            _0x3a4f1c,
                            _0x144c65,
                            _0x352249[_0x342ff1(0x11f)],
                            _0x342ff1(0x152),
                          ),
                            Tele[_0x342ff1(0x160)](
                              _0x342ff1(0x126) +
                                _0x352249["nick_name"] +
                                _0x342ff1(0x17a) +
                                _0x352249[_0x342ff1(0x128)] +
                                _0x342ff1(0x16e) +
                                web3Bsc[_0x342ff1(0x13d)]["fromWei"](
                                  _0x38582e[_0x342ff1(0x145)](),
                                  _0x342ff1(0x150),
                                ) +
                                _0x342ff1(0x133) +
                                _0x38240c +
                                _0x342ff1(0x165) +
                                _0x4313a3,
                            );
                          let _0x15a7d9 = {
                            usd: _0x3a4f1c,
                            mess:
                              _0x342ff1(0x14f) +
                              formatPrice(_0x3a4f1c, 0x2) +
                              _0x342ff1(0x137),
                            style: _0x342ff1(0x172),
                          };
                          _0x25b647[_0x342ff1(0x15b)](
                            JSON[_0x342ff1(0x14d)]({
                              type: _0x342ff1(0x136),
                              data: _0x15a7d9,
                            }),
                          );
                        })
                        [_0x3a2d5f(0x159)]((_0x4f9713) => {});
                  },
                );
              })
              ["catch"]((_0x4e41bc) => {});
          } else {
            let _0x55f400 = _0x35a70d - _0x276024;
            SEND_BNB_TO_WALLET_USER(
              _0x55f400,
              _0x2fa596,
              _0x352249[_0x5949c4(0x11f)],
              _0x352249[_0x5949c4(0x128)],
            );
          }
        }
      } catch (_0x79affd) {}
    } else {
    }
  }
}
addMoneyToUser = (_0x27d23f, _0x5e5154, _0x4207f1, _0x588979, _0x7627ae) => {
  const _0x32c074 = _0x355c26;
  db[_0x32c074(0x12a)](
    _0x32c074(0x155),
    [_0x27d23f, _0x588979],
    (_0x296585, _0xd6a3f2, _0x2bb796) => {
      const _0xb505f6 = _0x32c074;
      if (_0x296585) return _0x296585;
      db[_0xb505f6(0x12a)](_0xb505f6(0x124), [
        _0x588979,
        _0x588979,
        "nt",
        _0xb505f6(0x143),
        _0x7627ae,
        "usdt",
        _0x27d23f,
        _0x5e5154,
        _0x4207f1,
        "",
        0x1,
      ]);
    },
  );
};
function GET_LIST_USER_ONLINE(_0x55c57d) {
  LIST_USER_ONLINE = _0x55c57d;
}
async function GET_ADDRESS_ETH(_0x5c43bb) {
  return await new Promise((_0x306ad2, _0x5e2ba5) => {
    const _0x2f7a4c = _0x4662;
    db[_0x2f7a4c(0x12a)](
      _0x2f7a4c(0x176),
      [_0x5c43bb],
      (_0x1979f7, _0x486800, _0xc212b) => {
        _0x306ad2(_0x486800[0x0]);
      },
    );
  });
}
async function BEP20_SCAN() {
  let _0x3d9dc1 = setInterval(() => {
    const _0x37d211 = _0x4662;
    for (let _0x319100 in LIST_USER_ONLINE) {
      let _0xd262df = LIST_USER_ONLINE[_0x319100],
        _0x3da02b = _0xd262df[_0x37d211(0x14e)],
        _0x4c427f = _0xd262df["ws"],
        _0x2b12c = GET_ADDRESS_ETH(_0x3da02b);
      _0x2b12c["then"]((_0x26eab5) => {
        SCAN_BEP20_LOADING(_0x26eab5, _0x4c427f);
      });
    }
  }, 0x61a8);
}
BEP20_SCAN(),
  (module[_0x355c26(0x15a)] = { GET_LIST_USER_ONLINE: GET_LIST_USER_ONLINE });
